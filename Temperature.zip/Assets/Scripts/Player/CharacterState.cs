﻿public enum CharacterState
{
    IDLE,
    WALK,
    ATTACK,
    DIE
}