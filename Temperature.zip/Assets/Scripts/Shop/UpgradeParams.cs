﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class UpgradeParams : MonoBehaviour
{
    public int oil { get; set; }
}
