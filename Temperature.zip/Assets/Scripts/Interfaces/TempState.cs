﻿/// <summary>
/// 코어 상태(Hot, Cold)
/// </summary>
public enum TempState
{
    Hot,
    Cold
}
