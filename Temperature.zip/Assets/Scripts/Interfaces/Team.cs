﻿/// <summary>
/// 팀 구분(Red, Blue)
/// </summary>
public enum Team
{
    RED,
    BLUE
}